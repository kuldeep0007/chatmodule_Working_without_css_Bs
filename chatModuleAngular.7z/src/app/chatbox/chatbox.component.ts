import { Component, OnInit } from '@angular/core';
import { ChatService } from '../services/chat.service';

@Component({
  selector: 'app-chatbox',
  templateUrl: './chatbox.component.html',
  styleUrls: ['./chatbox.component.css']
})
export class ChatboxComponent implements OnInit {


  hasConversationsWithList = [];
  messagesBetweenUsers = [];
  newMessage = "";
  timer;
  firstClick=false;
  currentUser = 105;
  otherUser = undefined;

  constructor(private chatService: ChatService) {
    this.hasConversationsWith(this.currentUser);
    this.firstClick=false;
  }
  ngOnInit() {
  }
  // test() {
  //   console.log("hiie");
  // }


  //handleOnUserChatChange
  handleOnUserChatChange(otherUser) {
    clearInterval(this.timer)
    this.otherUser = otherUser;
    this.messagesBetweenUsers = [];
    this.getConversationOf(this.otherUser);
    this.RefreshUserChats(this.otherUser)
  }
  //handle sendMessage
  handleSendMessage() {
    let conversation = { "user1": this.currentUser, "user2": this.otherUser, "sender": this.currentUser, "content": this.newMessage };
    this.addNewMessage(conversation)

  }
  //function to refresh userchats
  RefreshUserChats(otherUser) {
    console.log("timer start");
    this.timer = setInterval(() => {
      this.chatService.getConversationOf({ "user1": this.currentUser, "user2": otherUser }).subscribe((messageData: test) => {
        this.messagesBetweenUsers = [];
        this.messagesBetweenUsers = messageData.val;
      });
    }, 2000);
  }



  //function to fatech userlist that user  has conversation with
  hasConversationsWith(user) {
    this.chatService.hasConversationsWith({ "user": user }).subscribe((userData: test) => {
      userData.val.map(conversation => {
        let userList = {
          "participant": conversation.participant[0],
          "sender": conversation.lastMessage.sender,
          "content": conversation.lastMessage.content,
          "timestamp": conversation.lastMessage.timestamp
        }
        this.hasConversationsWithList.push(userList);
      })
    })
  }
  //function to retrive messages between two users
  getConversationOf(otherUser) {
    this.chatService.getConversationOf({ "user1": this.currentUser, "user2": otherUser }).subscribe((messageData: test) => {
      this.messagesBetweenUsers = messageData.val;
    });
  }
  //function to add new message
  addNewMessage(messageObject) {
    console.log("add new msg called", messageObject);
    this.chatService.addNewMessage(messageObject).subscribe(data => {
      console.log(data);
    });
  }

  

}



interface test {
  val: any
}